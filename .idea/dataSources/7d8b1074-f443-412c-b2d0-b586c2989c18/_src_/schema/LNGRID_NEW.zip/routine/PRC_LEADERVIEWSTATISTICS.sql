CREATE procedure prc_leaderViewStatistics as
  count_sql varchar2(1800);--镇、街道(town)统计语句；
  ocount_sql varchar2(1000);--县区以上的统计语句；

  TYPE num_arry IS VARRAY(3) OF NUMBER(10);--声明一个数字型的数组；
  level_arr num_arry;--存放县以上的所有层级的level；

  TYPE str_arry IS VARRAY(25) OF VARCHAR2(60);--声明一个字符型的数组；
  tablename_arr str_arry;--没有注销字端的数据库表名数组；
  datatype_arr str_arry;--没有注销字端的数据类型数组
  itablename_arr str_arry;--有ISEMPHASIS字段的数据库表名数组；
  idatatype_arr str_arry;--有ISEMPHASIS字段的数据类型数组
  ltablename_arr str_arry;--有logOut字段数据库表名数组；
  ldatatype_arr str_arry;--有logOut字段数据类型数组

  iltablename_arr str_arry;--有ISEMPHASIS和logOutDate字段数据库表名数组；
  ildatatype_arr str_arry;--有ISEMPHASIS和logOutDate字段数据类型数组

  ilttablename_arr str_arry;--有ISEMPHASIS和logOutTime字段数据库表名数组；
  iltdatatype_arr str_arry;--有ISEMPHASIS和logOutTime字段数据类型数组

  slttablename_arr str_arry;--有status和logOutDate字段数据类型数组
  sltdatatype_arr str_arry;--有status和logOutDate字段数据类型数组

  xzorgtype number(10);--行政区域类型
  qtorgtype number(10);--其他类型；
  tlevel number(10);--镇、街道(town)对应的leve值
  dlevel number(10);--县区(district)对应的leve值
  clevel number(10);--市(city)city
  plevel NUMBER(10);--省(provice)
  vlevel number(10);--村、社区(village)对应的leve值
  glevel number(10);--片组片格(grid)对应的leve值
  --nlevel NUMBER(10);--全国(nation)
BEGIN
  EXECUTE IMMEDIATE 'TRUNCATE TABLE currenttotal_temp';
  --DBMS_OUTPUT.ENABLE(buffer_size => null);   --表示输出buffer不受限制
  select ID into xzorgtype from propertydicts ps where ps.displayname = '行政区域' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格类型');
  select ID into qtorgtype from propertydicts ps where ps.displayname = '其他' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格类型');

  --select ps.id into nlevel from propertydicts ps where ps.displayname = '全国' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into plevel from propertydicts ps where ps.displayname = '省' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into clevel from propertydicts ps where ps.displayname = '市' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into dlevel from propertydicts ps where ps.displayname = '县（区）' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into tlevel from propertydicts ps where ps.displayname = '乡镇（街道）' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into vlevel from propertydicts ps where ps.displayname = '村（社区）' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  select ps.id into glevel from propertydicts ps where ps.displayname = '片组片格' and ps.propertydomainid = (select id from propertydomains ps where ps.domainname = '网格分级');
  level_arr := num_arry(dlevel,clevel,plevel);--这一行顶下边下边注释的6行；

  --5类--有logout的使用：户籍、流动、境外、常住人口  ----(可能不要的部分)未落户,'rentalhouseNew'
  ltablename_arr := str_arry('householdStaffs','floatingPopulations','overseaPersonnel','residentPopulation','unsettledPopulations','floatingpopulationsnew');
  ldatatype_arr := str_arry('householdStaff','floatingPopulation','overseaStaff','residentPopulation','unsettledPopulation','floatingpopulationsnew');
  --logOut = '0' or logOut is null
  FOR i IN 1 .. ltablename_arr.count LOOP
    count_sql := 'INSERT INTO currenttotal_temp
      WITH TB1 AS (SELECT ORG.ORGINTERNALCODE,
      COUNT(CASE WHEN FPS.CREATEDATE >= trunc(SYSDATE) AND FPS.CREATEDATE < trunc(SYSDATE)+1 THEN 1 END) TODAYADDCOUNT,
      COUNT(CASE WHEN FPS.CREATEDATE>=trunc(SYSDATE, ''MM'') AND FPS.CREATEDATE< trunc(add_months(SYSDATE,1)) THEN 1 END) THISMONTHCOUNT,
      COUNT(CASE WHEN (FPS.logoutdate >= trunc(SYSDATE, ''MM'') AND FPS.logoutdate < trunc(add_months(SYSDATE, 1))) AND FPS.LOGOUT = 1 THEN 1 END) THISMONTHCANCELCOUNT,
      COUNT(CASE WHEN FPS.LOGOUT = 0 OR FPS.LOGOUT IS NULL THEN 1 END) ATTENTIONCOUNT,
      COUNT(1) ALLCOUNT FROM '||ltablename_arr(i)||' FPS,ORGANIZATIONS ORG
      WHERE FPS.ORGINTERNALCODE LIKE ORG.ORGINTERNALCODE || ''%'' AND orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||') GROUP BY ORG.ORGINTERNALCODE)

      SELECT ORG.parentid,ORGNAME AS STATISTICSTYPE,ORG.ORGINTERNALCODE,'''||ldatatype_arr(i)||''',nvl(TB1.TODAYADDCOUNT,0) AS TODAYADDCOUNT,
      nvl(TB1.THISMONTHCOUNT,0) AS THISMONTHCOUNT,nvl(TB1.THISMONTHCANCELCOUNT,0) AS THISMONTHCANCELCOUNT,nvl(TB1.ATTENTIONCOUNT,0) AS ATTENTIONCOUNT,nvl(TB1.ALLCOUNT,0) AS ALLCOUNT
      FROM (SELECT * FROM ORGANIZATIONS WHERE orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||')) ORG,TB1 where TB1.ORGINTERNALCODE(+) = ORG.ORGINTERNALCODE';
    DBMS_OUTPUT.PUT_LINE(count_sql);
    execute IMMEDIATE count_sql;

    --DBMS_OUTPUT.PUT_LINE(ldatatype_arr(i)||'    '||i);
    FOR j IN 1 .. level_arr.count LOOP
        ocount_sql := 'INSERT INTO currenttotal_temp
               SELECT distinct org.parentid,org.orgname,org.ORGINTERNALCODE,nvl(ls.MODULENAME,'''||ldatatype_arr(i)||'''),
               nvl(SUM(ls.todayaddcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.thismonthcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.THISMONTHCANCELCOUNT) over (partition by ls.porgid),0),
               nvl(SUM(ls.attentioncount) over (partition by ls.porgid),0),
               nvl(SUM(ls.allcount) over (partition by ls.porgid),0)
          FROM (SELECT * FROM organizations os WHERE os.orglevel = '||level_arr(j)||' AND os.orgtype IN ('||xzorgtype||','||qtorgtype||')) org
          LEFT JOIN (SELECT * FROM currenttotal_temp ls WHERE ls.MODULENAME = '''||ldatatype_arr(i)||''')ls ON ls.porgid = org.id';
        --DBMS_OUTPUT.PUT_LINE(ocount_sql);
        execute IMMEDIATE ocount_sql;
    END LOOP;
    COMMIT;
  END LOOP;

  ----有ISEMPHASIS的使用：刑满释放、社区服刑、精神病、吸毒人员、艾滋病感染者、重点上访、其他重点工作对象、重点上访、重点青少年、学校、出租房
            ----(可能不要的部分)老年人、残疾人、优抚对象、需救助人员
            ----(可能不要的部分)育龄妇女、失业人员
            ----(可能不要的部分)实有单位、新经济组织
            ----(可能不要的部分)安全生产重点、消防安全重点、治安重点、危险化学品单位、上网服务单位、公共场所、其他场所
        ----有ISEMPHASIS显示注销字段，但是使用logoutDate LOGOUTTIME显示注销时间的类型：出租房；
  iltablename_arr := str_arry('rentalHouse');
  ildatatype_arr :=  str_arry('rentalHouse');
  --ISEMPHASIS = '0' or ISEMPHASIS is null
  FOR i IN 1 .. iltablename_arr.count LOOP
    --DBMS_OUTPUT.PUT_LINE(iltablename_arr(i));
    count_sql := 'INSERT INTO currenttotal_temp
      WITH TB1 AS (SELECT ORG.ORGINTERNALCODE,
      COUNT(CASE WHEN FPS.CREATEDATE >= trunc(SYSDATE) AND FPS.CREATEDATE < trunc(SYSDATE)+1 THEN 1 END) TODAYADDCOUNT,
      COUNT(CASE WHEN FPS.CREATEDATE>=trunc(SYSDATE, ''MM'') AND FPS.CREATEDATE< trunc(add_months(SYSDATE,1)) THEN 1 END) THISMONTHCOUNT,
      COUNT(CASE WHEN (FPS.logoutdate >= trunc(SYSDATE, ''MM'') AND FPS.logoutdate < trunc(add_months(SYSDATE, 1))) AND FPS.ISEMPHASIS = 1 THEN 1 END) THISMONTHCANCELCOUNT,
      COUNT(CASE WHEN FPS.ISEMPHASIS = 0 OR FPS.ISEMPHASIS IS NULL THEN 1 END) ATTENTIONCOUNT,
      COUNT(1) ALLCOUNT FROM '||iltablename_arr(i)||' FPS,ORGANIZATIONS ORG
      WHERE FPS.ORGINTERNALCODE LIKE ORG.ORGINTERNALCODE || ''%'' AND orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||') GROUP BY ORG.ORGINTERNALCODE)

      SELECT ORG.parentid,ORGNAME AS STATISTICSTYPE,ORG.ORGINTERNALCODE,'''||ildatatype_arr(i)||''',nvl(TB1.TODAYADDCOUNT,0) AS TODAYADDCOUNT,
      nvl(TB1.THISMONTHCOUNT,0) AS THISMONTHCOUNT,nvl(TB1.THISMONTHCANCELCOUNT,0) AS THISMONTHCANCELCOUNT,nvl(TB1.ATTENTIONCOUNT,0) AS ATTENTIONCOUNT,nvl(TB1.ALLCOUNT,0) AS ALLCOUNT
      FROM (SELECT * FROM ORGANIZATIONS WHERE orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||')) ORG,TB1 where TB1.ORGINTERNALCODE(+) = ORG.ORGINTERNALCODE';
    --DBMS_OUTPUT.PUT_LINE(count_sql);--iltablename_arr(i)
    execute IMMEDIATE count_sql;

    FOR j IN 1 .. level_arr.count LOOP
        ocount_sql := 'INSERT INTO currenttotal_temp
               SELECT distinct org.parentid,org.orgname,org.ORGINTERNALCODE,nvl(ls.MODULENAME,'''||ildatatype_arr(i)||'''),
               nvl(SUM(ls.todayaddcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.thismonthcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.THISMONTHCANCELCOUNT) over (partition by ls.porgid),0),
               nvl(SUM(ls.attentioncount) over (partition by ls.porgid),0),
               nvl(SUM(ls.allcount) over (partition by ls.porgid),0)
          FROM (SELECT * FROM organizations os WHERE os.orglevel = '||level_arr(j)||' AND os.orgtype IN ('||xzorgtype||','||qtorgtype||')) org
          LEFT JOIN (SELECT * FROM currenttotal_temp ls WHERE ls.MODULENAME = '''||ildatatype_arr(i)||''')ls ON ls.porgid = org.id';
        --DBMS_OUTPUT.PUT_LINE(ocount_sql);
        execute IMMEDIATE ocount_sql;
    END LOOP;
    COMMIT;
  END LOOP;

          ----有ISEMPHASIS显示注销字段，但是使用LOGOUTTIME显示注销时间的类型：出租房；
  ilttablename_arr := str_arry('actualCompany','dangerousChemicalsUnit','internetBar','publicPlace');
  iltdatatype_arr :=  str_arry('actualCompany','DANGEROUSCHEMICALSUNIT','INTERNETBAR','PUBLICPLACE');
  --ISEMPHASIS = '0' or ISEMPHASIS is null
  FOR i IN 1 .. ilttablename_arr.count LOOP
    --DBMS_OUTPUT.PUT_LINE(ilttablename_arr(i));
    count_sql := 'INSERT INTO currenttotal_temp
      WITH TB1 AS (SELECT ORG.ORGINTERNALCODE,
      COUNT(CASE WHEN FPS.CREATEDATE >= trunc(SYSDATE) AND FPS.CREATEDATE < trunc(SYSDATE)+1 THEN 1 END) TODAYADDCOUNT,
      COUNT(CASE WHEN FPS.CREATEDATE>=trunc(SYSDATE, ''MM'') AND FPS.CREATEDATE< trunc(add_months(SYSDATE,1)) THEN 1 END) THISMONTHCOUNT,
      COUNT(CASE WHEN (FPS.LOGOUTTIME >= trunc(SYSDATE, ''MM'') AND FPS.LOGOUTTIME < trunc(add_months(SYSDATE, 1))) AND FPS.ISEMPHASIS = 1 THEN 1 END) THISMONTHCANCELCOUNT,
      COUNT(CASE WHEN FPS.ISEMPHASIS = 0 OR FPS.ISEMPHASIS IS NULL THEN 1 END) ATTENTIONCOUNT,
      COUNT(1) ALLCOUNT FROM '||ilttablename_arr(i)||' FPS,ORGANIZATIONS ORG
      WHERE FPS.ORGINTERNALCODE LIKE ORG.ORGINTERNALCODE || ''%'' AND orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||') GROUP BY ORG.ORGINTERNALCODE)

      SELECT ORG.parentid,ORGNAME AS STATISTICSTYPE,ORG.ORGINTERNALCODE,'''||iltdatatype_arr(i)||''',nvl(TB1.TODAYADDCOUNT,0) AS TODAYADDCOUNT,
      nvl(TB1.THISMONTHCOUNT,0) AS THISMONTHCOUNT,nvl(TB1.THISMONTHCANCELCOUNT,0) AS THISMONTHCANCELCOUNT,nvl(TB1.ATTENTIONCOUNT,0) AS ATTENTIONCOUNT,nvl(TB1.ALLCOUNT,0) AS ALLCOUNT
      FROM (SELECT * FROM ORGANIZATIONS WHERE orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||')) ORG,TB1 where TB1.ORGINTERNALCODE(+) = ORG.ORGINTERNALCODE';
    --DBMS_OUTPUT.PUT_LINE(count_sql);--ilttablename_arr(i)
    execute IMMEDIATE count_sql;

    FOR j IN 1 .. level_arr.count LOOP
        ocount_sql := 'INSERT INTO currenttotal_temp
               SELECT distinct org.parentid,org.orgname,org.ORGINTERNALCODE,nvl(ls.MODULENAME,'''||iltdatatype_arr(i)||'''),
               nvl(SUM(ls.todayaddcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.thismonthcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.THISMONTHCANCELCOUNT) over (partition by ls.porgid),0),
               nvl(SUM(ls.attentioncount) over (partition by ls.porgid),0),
               nvl(SUM(ls.allcount) over (partition by ls.porgid),0)
          FROM (SELECT * FROM organizations os WHERE os.orglevel = '||level_arr(j)||' AND os.orgtype IN ('||xzorgtype||','||qtorgtype||')) org
          LEFT JOIN (SELECT * FROM currenttotal_temp ls WHERE ls.MODULENAME = '''||iltdatatype_arr(i)||''')ls ON ls.porgid = org.id';
        --DBMS_OUTPUT.PUT_LINE(ocount_sql);
        execute IMMEDIATE ocount_sql;
    END LOOP;
    COMMIT;
  END LOOP;

  itablename_arr := str_arry('positiveinfos','rectificativePersons','mentalPatients','druggys','aidsPopulations','dangerousGoodsPractitioners','superiorVisits','idleYouths','schools',
                'elderlyPeople','handicappeds','optimalObjects','aidneedpopulation',
                'nurturesWomen','unemployedPeople',
                'newEconomicOrganizations',
                'safetyProductionKey','securityKey','firesafetykey','otherLocales');
  idatatype_arr :=  str_arry('positiveInfo','rectificativePerson','mentalPatient','druggy','aidspopulations','dangerousGoodsPractitioner','superiorVisit','idleYouth','SCHOOL',
                'elderlyPeople','handicapped','optimalObject','aidNeedPopulation',
                'nurturesWomen','unemployedPeople',
                'NEWECONOMICORGANIZATIONS',
                'SAFETYPRODUCTIONKEY','SECURITYKEY','FIRESAFETYKEY','OTHERLOCALE');
  --ISEMPHASIS = '0' or ISEMPHASIS is null
  FOR i IN 1 .. itablename_arr.count LOOP
    --DBMS_OUTPUT.PUT_LINE(itablename_arr(i));
    count_sql := 'INSERT INTO currenttotal_temp
      WITH TB1 AS (SELECT ORG.ORGINTERNALCODE,
      COUNT(CASE WHEN FPS.CREATEDATE >= trunc(SYSDATE) AND FPS.CREATEDATE < trunc(SYSDATE)+1 THEN 1 END) TODAYADDCOUNT,
      COUNT(CASE WHEN FPS.CREATEDATE>=trunc(SYSDATE, ''MM'') AND FPS.CREATEDATE< trunc(add_months(SYSDATE,1)) THEN 1 END) THISMONTHCOUNT,
      COUNT(CASE WHEN (FPS.ISEMPHASISDATE >= trunc(SYSDATE, ''MM'') AND FPS.ISEMPHASISDATE < trunc(add_months(SYSDATE, 1))) AND FPS.ISEMPHASIS = 1 THEN 1 END) THISMONTHCANCELCOUNT,
      COUNT(CASE WHEN FPS.ISEMPHASIS = 0 OR FPS.ISEMPHASIS IS NULL THEN 1 END) ATTENTIONCOUNT,
      COUNT(1) ALLCOUNT FROM '||itablename_arr(i)||' FPS,ORGANIZATIONS ORG
      WHERE FPS.ORGINTERNALCODE LIKE ORG.ORGINTERNALCODE || ''%'' AND orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||') GROUP BY ORG.ORGINTERNALCODE)

      SELECT ORG.parentid,ORGNAME AS STATISTICSTYPE,ORG.ORGINTERNALCODE,'''||idatatype_arr(i)||''',nvl(TB1.TODAYADDCOUNT,0) AS TODAYADDCOUNT,
      nvl(TB1.THISMONTHCOUNT,0) AS THISMONTHCOUNT,nvl(TB1.THISMONTHCANCELCOUNT,0) AS THISMONTHCANCELCOUNT,nvl(TB1.ATTENTIONCOUNT,0) AS ATTENTIONCOUNT,nvl(TB1.ALLCOUNT,0) AS ALLCOUNT
      FROM (SELECT * FROM ORGANIZATIONS WHERE orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||')) ORG,TB1 where TB1.ORGINTERNALCODE(+) = ORG.ORGINTERNALCODE';
    --DBMS_OUTPUT.PUT_LINE(count_sql);--itablename_arr(i)
    execute IMMEDIATE count_sql;

    FOR j IN 1 .. level_arr.count LOOP
        ocount_sql := 'INSERT INTO currenttotal_temp
               SELECT distinct org.parentid,org.orgname,org.ORGINTERNALCODE,nvl(ls.MODULENAME,'''||idatatype_arr(i)||'''),
               nvl(SUM(ls.todayaddcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.thismonthcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.THISMONTHCANCELCOUNT) over (partition by ls.porgid),0),
               nvl(SUM(ls.attentioncount) over (partition by ls.porgid),0),
               nvl(SUM(ls.allcount) over (partition by ls.porgid),0)
          FROM (SELECT * FROM organizations os WHERE os.orglevel = '||level_arr(j)||' AND os.orgtype IN ('||xzorgtype||','||qtorgtype||')) org
          LEFT JOIN (SELECT * FROM currenttotal_temp ls WHERE ls.MODULENAME = '''||idatatype_arr(i)||''')ls ON ls.porgid = org.id';
        --DBMS_OUTPUT.PUT_LINE(ocount_sql);
        execute IMMEDIATE ocount_sql;
    END LOOP;
    COMMIT;
  END LOOP;


  --2--没有注销字段的：实有房屋   ----(可能不要的部分)楼宇
  tablename_arr := str_arry('houseinfo','builddatas');
  datatype_arr := str_arry('actualHouse','builddatas');
  FOR i IN 1 .. tablename_arr.count LOOP
    count_sql := 'INSERT INTO currenttotal_temp
      WITH TB1 AS (SELECT ORG.ORGINTERNALCODE,
      COUNT(CASE WHEN FPS.CREATEDATE >= trunc(SYSDATE) AND FPS.CREATEDATE < trunc(SYSDATE)+1 THEN 1 END) TODAYADDCOUNT,
      COUNT(CASE WHEN FPS.CREATEDATE>=trunc(SYSDATE, ''MM'') AND FPS.CREATEDATE< trunc(add_months(SYSDATE,1)) THEN 1 END) THISMONTHCOUNT,
      0 THISMONTHCANCELCOUNT,
      COUNT(1) ATTENTIONCOUNT,
      COUNT(1) ALLCOUNT FROM '||tablename_arr(i)||' FPS,ORGANIZATIONS ORG
      WHERE FPS.ORGINTERNALCODE LIKE ORG.ORGINTERNALCODE || ''%'' AND orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||') GROUP BY ORG.ORGINTERNALCODE)

      SELECT ORG.parentid,ORGNAME AS STATISTICSTYPE,ORG.ORGINTERNALCODE,'''||datatype_arr(i)||''',nvl(TB1.TODAYADDCOUNT,0) AS TODAYADDCOUNT,
      nvl(TB1.THISMONTHCOUNT,0) AS THISMONTHCOUNT,nvl(TB1.THISMONTHCANCELCOUNT,0) AS THISMONTHCANCELCOUNT,nvl(TB1.ATTENTIONCOUNT,0) AS ATTENTIONCOUNT,nvl(TB1.ALLCOUNT,0) AS ALLCOUNT
      FROM (SELECT * FROM ORGANIZATIONS WHERE orglevel = '||vlevel||' AND ORGTYPE IN ('||xzorgtype||','||qtorgtype||')) ORG,TB1 where TB1.ORGINTERNALCODE(+) = ORG.ORGINTERNALCODE';
    --DBMS_OUTPUT.PUT_LINE(count_sql);
    execute IMMEDIATE count_sql;

     FOR j IN 1 .. level_arr.count LOOP
        ocount_sql := 'INSERT INTO currenttotal_temp
               SELECT distinct org.parentid,org.orgname,org.ORGINTERNALCODE,nvl(ls.MODULENAME,'''||datatype_arr(i)||'''),
               nvl(SUM(ls.todayaddcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.thismonthcount) over (partition by ls.porgid),0),
               nvl(SUM(ls.THISMONTHCANCELCOUNT) over (partition by ls.porgid),0),
               nvl(SUM(ls.attentioncount) over (partition by ls.porgid),0),
               nvl(SUM(ls.allcount) over (partition by ls.porgid),0)
          FROM (SELECT * FROM organizations os WHERE os.orglevel = '||level_arr(j)||' AND os.orgtype IN ('||xzorgtype||','||qtorgtype||')) org
          LEFT JOIN (SELECT * FROM currenttotal_temp ls WHERE ls.MODULENAME = '''||datatype_arr(i)||''')ls ON ls.porgid = org.id';
        --DBMS_OUTPUT.PUT_LINE(ocount_sql);
        execute IMMEDIATE ocount_sql;
    END LOOP;
    COMMIT;
  END LOOP;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE currenttotal';
    INSERT INTO currenttotal SELECT * FROM currenttotal_temp;
  COMMIT;
END prc_leaderViewStatistics;
/
